<?php
    class Horario{
        private $hora;
        private $minuto;
        private $segundo;

        public function __construct($hora, $minuto, $segundo){
            $this->setHora($hora);
            $this->setMinuto($minuto);
            $this->setSegundo($segundo);
    
        }

        public function getHora() {
            return $this->hora;
        }

        public function setHora($hora){
            if ($hora >=0 and $hora <= 23) {
                $this->hora = $hora;
            } else {
                $this->hora = 0;
            }
        }

        public function getMinuto() {       
            return $this->minuto;
        }

        public function setMinuto($minuto){
            if ($minuto >=0 and $minuto <= 59) {
                $this->minuto = $minuto;
            } else {
                $this->minuto = 0;
            }
        }

        public function getSegundo() {       
            return $this->minuto;
        }

        public function setSegundo($segundo){
            if ($segundo >=0 and $segundo <= 59) {
                $this->segundo = $segundo;
            } else {
                $this->segundo = 0;
            }
        }

        public function tick() {
            $this->setSegundo($this->segundo + 1);

            if ($this->segundo == 0) {
                $this->setMinuto($this->minuto+1);

                if($this->minuto == 0)
                    $this->setHora($this->hora+1);
            }

        }

        public function __toString() {
            return "<p>" . $this->hora . ":" . $this->minuto . ":" . $this->segundo;
        }

    }