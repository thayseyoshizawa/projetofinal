<?php
    require "Jogo.php";
    $meuJogo = new Jogo('The last of us', 'ps4', 207836423722);
    $meuJogo-> imprimir();
    $meuJogo-> valor=207836423722;
    $meuJogo-> imprimir();