<?php
    interface EmprestavelInterface{
        public function emprestar();
        public function devolver();
    }

