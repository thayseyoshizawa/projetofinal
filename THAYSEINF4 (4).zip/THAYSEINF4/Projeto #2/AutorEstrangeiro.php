<?php
    class AutorEstrangeiro extends Autor {
        private $pais;

        public function __construct($id, $nome, $pais) {
            parent::__construct($id, $nome);
            $this-> pais = $pais;

        }

        public function getPais() {
            return $this -> pais;
        }

        public function setPais($pais) {
            $this -> pais = $pais;
        }

        public function imprimir(){
            echo '<p>País: '  . $this->pais;

        }

        
        
    }