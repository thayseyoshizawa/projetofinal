<?php
    require "Autor.php";
    require "AutorEstrangeiro.php"; 
    require "Livro.php";
    require "Revista.php";
    require "Editora.php";
    require "Categoria.php";

   
$autor = new AutorEstrangeiro(1, "Bel hooks", "Estados Unidos");
$editora = new Editora("Elefante", "Rua Abluble, 123");
$categoria = new Categoria(1, "Autoajuda");
$livro = new Livro("Tudo sobre Amor", $autor, $categoria, $editora);

$livro->imprimir();
?>

     