<?php
    class Vendedor{
        private $nome;
        private $comissao;


        public function __construct($nome, $comissao){
            $this-> nome = $nome;
            $this-> comissao = $comissao;
        }

        public function vender(){
            echo "<p>Venda realizada. Vendedor: " . $this->nome;
        }

        public function __toString(){
            return "<p> Vendedor: " . $this->nome;
        }
    }

