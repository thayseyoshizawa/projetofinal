<?php
    interface BancoDeDados{
        public function conectar($servidor);
        public function inserir();
        public function alterar();

    }

