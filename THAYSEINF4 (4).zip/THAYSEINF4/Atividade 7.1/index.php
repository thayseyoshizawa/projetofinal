<?php

    require "BancoDeDados.php";
    require "MySQL.php";
    require "PostgreSQL.php";

    $meuBD = new MySQL();
    $meuBD->conectar("localhost");
    $meuBD->inserir();
    $meuBD->alterar();