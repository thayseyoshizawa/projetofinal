<?php
    interface AnimalInterface{
        public function getNome();
        public function getIdade();
        public function emitirSom();

    }

