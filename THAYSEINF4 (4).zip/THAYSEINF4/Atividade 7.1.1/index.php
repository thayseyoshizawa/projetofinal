<?php
    require "AnimalInterface.php";
    require "Leao.php";
    require "Elefante.php";
    require "Macaco.php";
    
    $animais = array(
        new Leao("Simba", 5),
        new Elefante("Dumbo", 10),
        new Macaco("Curió", 3)
    );
    
    foreach($animais as $animal) {
        echo "<p>Nome: " . $animal->getNome();
        echo "<p>Idade: " . $animal->getIdade();
        $animal->emitirSom();
    }
