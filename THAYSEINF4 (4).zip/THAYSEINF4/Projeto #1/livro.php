<?php
class livro {
    private $id;
    private $titulo;
    private $autor; 
    private $categoria; 
    private $editora; 

    public function __construct($id, $titulo, $autor, $categoria, $editora) {
        $this -> id = $id;
        $this -> titulo = $titulo;
        $this -> autor = $autor;
        $this -> categoria = $categoria;
        $this -> editora = $editora;
    }

    public function getId() {
        return $this -> id;
    }

    public function getTitulo() {
        return $this -> titulo;
    }

    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
    }

    public function getAutor() {
        return $this -> autor;
    }

    public function setAutor($autor) {
        $this -> autor = $autor;
    }

    public function getCategoria() {
        return $this -> categoria;
    }

    public function setCategoria($categoria) {
        $this -> categoria = $categoria;
    }

    public function getEditora() {
        return $this -> editora;
    }

    public function setEditora($editora) {
        $this -> editora = $editora;
    }

    public function imprimir(){
        echo '<p>Id: . ' . $this ->id;
        echo '<p>Titulo: '  . $this->titulo;
        echo '<p>Autor: '  . $this->autor->getNome();
        echo '<p>Editora: '  . $this->editora->getNome();
        echo '<p>Categoria: '  . $this->categoria->getNome();

    }
}