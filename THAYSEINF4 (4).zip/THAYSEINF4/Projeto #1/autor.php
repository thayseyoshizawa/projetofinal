<?php
    class autor {
        private $id;
        private $nome;

        public function __construct($id, $nome) {
            $this -> id = $id;
            $this -> nome = $nome;
        }

        public function getId() {
            return $this -> id;
        }
        
        public function getNome() {
            return $this -> nome;
        }

        public function setNome($nome) {
            $this -> nome = $nome;
        }

        public function imprimir(){
            echo '<p>Id: . ' . $this ->id;
            echo '<p>Nome: '  . $this->nome;

        }

    }