<?php
    require "Autor.php";
    require "Livro.php";
    require "Editora.php";
    require "Categoria.php";

   
    $meuAutor = new Autor('1234', $utor);
    $minhaCategoria = new Categoria('1234', $categoria);
    $minhaEditora = new Editora($editora, 'nomee' );
    $meuLivro = new Livro('1234', 'Tituloo', $meuAutor, $minhaCategoria, $minhaEditora);
    $meuLivro -> imprimir();
   



     