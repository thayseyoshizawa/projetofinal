<?php
    require "Autor.php";
    require "Categoria.php";
    require "Editora.php";
    require "Livro.php";

    // Receber os dados do form

    $autor = $_POST['autor'];
    $categoria = $_POST['categoria'];
    $editora = $_POST['editora'];
    $id = $_POST['id'];
    $titulo = $_POST['titulo'];

    $objAutor = new Autor(2345, $autor);
    $objCategoria = new Categoria(6789, $categoria);
    $objEditora = new Editora($editora, 'Telêmaco Borba');

    // Instanciar o objeto da classe ContaEspecial
    $meuLivro = new Livro($id, $titulo, $objAutor, $objCategoria, $objEditora);
    $meuLivro->imprimir();