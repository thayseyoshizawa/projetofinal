<?php
    require ".../.../autoload.php";

    // CONSTUIR OP OBJETO FONRCEODOR
    $fornecedor = new Fornecedor();
    $fornecedor->setCnpj($_POST['cnpj']);
    $fornecedor->setRazaoSocial($_POST['razao_social']);
    $fornecedor->setEmail($_POST['email']);
    $fornecedor->setTelefone($_POST['telefone']);

    // INSERIR NO BANCO DE DADOS
    $dao = new FornecedorDAO();
    $dao->create($fornecedor);

    // REDIRECIONAR PARA O INDEX X 
    header('Location:index.php');
