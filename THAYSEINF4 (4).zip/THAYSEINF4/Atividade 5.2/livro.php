<?php
class livro {
    private $titulo;
    private $anoPublicacao;
    private $autor; 

    public function __construct($titulo, $anoPublicacao, $autor) {
        $this -> titulo = $titulo;
        $this -> anoPublicacao = $anoPublicacao;
        $this -> autor = $autor;
    }

    public function getTitulo() {
        return $this -> titulo;
    }

    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
    }

    public function getAnoPublicacao() {
        return $this -> anoPublicacao;
    }

    public function setAnoPublicacao($anoPublicacao) {
        $this -> anoPublicacao = $anoPublicacao;
    }

    public function getAutor() {
        return $this -> autor;
    }

    public function setAutor($autor) {
        $this -> autor = $autor;
    }

    public function descricaoCompleta() {
        echo "<p>Livro: " . $this -> titulo;
        echo "<p>Ano de Publicação: " . $this -> anoPublicacao;
        echo $this -> autor;
    }
}