<?php
    require "ContaCorrente.php";
    require "ContaEspecial.php";

    // Receber os dados do form
    $Agencia = $_POST['Agencia'];
    $Conta = $_POST['Conta'];
    $Nome = $_POST['Nome'];
    $Saldo = $_POST['Saldo'];

    // Instanciar o objeto da classe ContaEspecial
    $minhaConta = new ContaEspecial($Agencia, $Conta, $Nome, $Saldo);
    $minhaConta -> Imprimir();