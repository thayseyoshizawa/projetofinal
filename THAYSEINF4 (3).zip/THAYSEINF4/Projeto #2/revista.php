<?php
class Revista implements EmprestavelInterface{
    private $titulo;
    private $editora; 

    public function __construct($titulo, $editora) {
        $this -> titulo = $titulo;
        $this -> editora = $editora;
    }

      public function getTitulo() {
        return $this -> titulo;
    }

    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
    }

    public function getEditora() {
        return $this -> editora;
    }

    public function setEditora($editora) {
        $this -> editora = $editora;
    }

    public function emprestar(){
       echo '<p> Revista ' . $this->titulo . 'Devolvido';
     
    }

    public function devolver(){
        echo '<p> Revista ' . $this->titulo . 'Devolvido';
    }

    public function imprimir(){
        echo '<p>Titulo: '  . $this->titulo;
        echo '<p>Editora: '  . $this->editora->getNome();

    }
}