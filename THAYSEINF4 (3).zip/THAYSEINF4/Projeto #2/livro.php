<?php
 require_once 'EmprestavelInterface.php';

class Livro implements EmprestavelInterface{
    private $titulo;
    private $autor; 
    private $categoria; 
    private $editora; 

    public function __construct( $titulo, $autor, $categoria, $editora) {
        $this -> titulo = $titulo;
        $this -> autor = $autor;
        $this -> categoria = $categoria;
        $this -> editora = $editora;
    }

    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
    }

    public function getAutor() {
        return $this -> autor;
    }

    public function setAutor($autor) {
        $this -> autor = $autor;
    }

    public function getCategoria() {
        return $this -> categoria;
    }

    public function setCategoria($categoria) {
        $this -> categoria = $categoria;
    }

    public function getEditora() {
        return $this -> editora;
    }

    public function setEditora($editora) {
        $this -> editora = $editora;
    }

    public function emprestar(){
        echo '<p>Livro ' . $this->titulo  . ' Foi emprestado</p>';
     
    }

    public function devolver(){
        echo '<p>Livro ' . $this->titulo . ' Foi devolvido</p>';
    }

    public function imprimir() {
    echo '<p>Título: ' . $this->titulo;
    echo '<p>Autor: ' . $this->autor->getNome();
    echo '<p>Editora: ' . $this->editora->getNome();
    echo '<p>Categoria: ' . $this->categoria->getNome();
}

}