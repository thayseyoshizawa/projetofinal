<?php
    require "Autor.php";
    require "AutorEstrangeiro.php";
    require "Categoria.php";
    require "Editora.php";
    require "Livro.php";

    // Receber os dados do form

    $autor = $_POST['autor'];
    $categoria = $_POST['categoria'];
    $editora = $_POST['editora'];
    $titulo = $_POST['titulo'];

    $objAutor = new AutorEstrangeiro(2345, $autor,'Brasil');
    $objCategoria = new Categoria(6789, $categoria);
    $objEditora = new Editora($editora, 'Telêmaco Borba');

    // Instanciar o objeto da classe ContaEspecial
    $meuLivro = new Livro($titulo, $objAutor, $objCategoria, $objEditora);
    $meuLivro->imprimir();
    $meuLivro->Emprestar();