<?php
require "autor.php";
require "livro.php";

// Instanciando um autor
$objAutor = new autor("George Orwell", "Britânico-inglês");

// Instanciando um livro
$objLivro = new livro("1984",1949, $objAutor);

// Exibindo a descrição completa do livro
$objLivro -> descricaoCompleta();