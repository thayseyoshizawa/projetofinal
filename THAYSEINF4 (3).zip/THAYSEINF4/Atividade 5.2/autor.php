<?php
    class autor {
        private $nome;
        private $nacionalidade;


        public function __construct($nome, $nacionalidade) {
            $this -> nome = $nome;
            $this -> nacionalidade = $nacionalidade;
        }

        public function getNome() {
            return $this -> nome;
        }

        public function setNome($nome) {
            $this -> nome = $nome;
        }

        public function getNacionalidade() {
            return $this -> nome;
        }

        public function setNacionalidade($nacionalidade) {
            $this -> nacionalidade = $nacionalidade;
        }

        public function __toString() {
            return "<p>Autor: " . $this -> nome . " (" . $this -> nacionalidade . ")";
        }
    }