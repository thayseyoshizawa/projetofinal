<?php 
class Emprestimo {
    public function create($emprestimo){
        try {
            $query = BD::getConexao()->prepare("INSERT INTO emprestimo(dataEmprestimo, dataDevolucao) VALUES(:de,:dd)");
            $query->bindValue(':de', $emprestimo-getDataEmprestimo(), PDO::PARAM_STR);
            $query->bindValue(':dd', $emprestimo-getDataDevolucao(), PDO::PARAM_STR);
            if(!$query->execute())
                print_r($query->errorInfo());
        
        }
        catch(PDOException $e){
            echo"Erro número 1: " . $e->getMessage();
        }
    }

    public function read(){
        
        try {
            $query = BD::getConexao()->prepare("SELECT * FROM emprestimo");
            if(!$query->execute())
                print_r($query->errorInfo());
            
            $emprestimos = array();
            foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha){
                $emprestimo = new Emprestimo();
                $emprestimo->setId($linha['id_emprestimo']);
                $emprestimo->setDataEmprestimo($linha['dataEmprestimo']);
                $emprestimo->setDataDevolucao($linha['dataDevolucao']);

                array_push($emprestimos, $emprestimo);
            }

            return $emprestimos;
        }


        catch(PDOException $e){
            echo"Erro número 2: " . $e->getMessage();
        }
    }
    
}