<?php 
class Livro {
    public function create($livro){
        try {
            $query = BD::getConexao()->prepare("INSERT INTO livro(titulo,anoPublicacao,edicao) VALUES(:t,:a,:e)");
            $query->bindValue(':t', $livro-getTitulo(), PDO::PARAM_STR);
            $query->bindValue(':a', $livro-getAnoPublicacao(), PDO::PARAM_STR);
            $query->bindValue(':e', $livro-getEdicao(), PDO::PARAM_STR);

            if(!$query->execute())
                print_r($query->errorInfo());
        
        }
        catch(PDOException $e){
            echo"Erro número 1: " . $e->getMessage();
        }
    }

    public function read(){
        
        try {
            $query = BD::getConexao()->prepare("SELECT * FROM livro");
            if(!$query->execute())
                print_r($query->errorInfo());
            
            $livros = array();
            foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha){
                $livro = new Livro();
                $livro->setId($linha['id_livro']);
                $livro->setTitulo($linha['titulo']);
                $livro->setAnoPublicacao($linha['anoPublicacao']);
                $livro->setEdicao($linha['edicao']);

                array_push($livros, $livro);
            }

            return $livros;
        }


        catch(PDOException $e){
            echo"Erro número 2: " . $e->getMessage();
        }
    }
    
}