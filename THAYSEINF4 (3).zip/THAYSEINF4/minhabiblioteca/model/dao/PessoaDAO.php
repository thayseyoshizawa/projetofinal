<?php 
class Pessoa {
    public function create($pessoa){
        try {
            $query = BD::getConexao()->prepare("INSERT INTO pessoa(nome) VALUES(:n");
            $query->bindValue(':n', $pessoa-getNome(), PDO::PARAM_STR);
    
            if(!$query->execute())
                print_r($query->errorInfo());
        
        }
        catch(PDOException $e){
            echo"Erro número 1: " . $e->getMessage();
        }
    }

    public function read(){
        
        try {
            $query = BD::getConexao()->prepare("SELECT * FROM pessoa");
            if(!$query->execute())
                print_r($query->errorInfo());
            
            $pessoas = array();
            foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha){
                $pessoa = new Pessoa();
                $pessoa->setId($linha['id_pessoa']);
                $pessoa->setNome($linha['nome']);
            
                array_push($pessoas, $pessoa);
            }

            return $pessoas;
        }


        catch(PDOException $e){
            echo"Erro número 2: " . $e->getMessage();
        }
    }
    
}