<?php 
class Editora {
    public function create($editora){
        try {
            $query = BD::getConexao()->prepare("INSERT INTO editora(nome, endereco) VALUES(:n,:e)");
            $query->bindValue(':n', $editora-getNome(), PDO::PARAM_STR);
            $query->bindValue(':e', $editora-getEndereco(), PDO::PARAM_STR);
            if(!$query->execute())
                print_r($query->errorInfo());
        
        }
        catch(PDOException $e){
            echo"Erro número 1: " . $e->getMessage();
        }
    }

    public function read(){
        
        try {
            $query = BD::getConexao()->prepare("SELECT * FROM editora");
            if(!$query->execute())
                print_r($query->errorInfo());
            
            $editoras = array();
            foreach($query->fetchAll(PDO::FETCH_ASSOC) as $linha){
                $editora = new Editora();
                $editora->setId($linha['id_editora']);
                $editora->setNome($linha['nome']);
                $editora->setEndereco($linha['endereco']);

                array_push($editoras, $editora);
            }

            return $editoras;
        }


        catch(PDOException $e){
            echo"Erro número 2: " . $e->getMessage();
        }
    }
    
}