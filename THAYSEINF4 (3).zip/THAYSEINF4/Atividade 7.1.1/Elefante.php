<?php
    class Elefante implements AnimalInterface{
        public $nome;
        public $idade;


        public function __construct($nome, $idade) {
            $this -> nome = $nome;
            $this -> idade = $idade;
        }

        public function getNome() {
            return $this -> nome;
        }    

        public function getIdade() {
            return $this -> idade;
        }   

        public function emitirSom(){
            echo "<p>O Elefante faz: FUUMMM UUUHHHH";
        }
    }