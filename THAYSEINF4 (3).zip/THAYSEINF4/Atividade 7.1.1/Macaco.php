<?php
    class Macaco implements AnimalInterface{
        public $nome;
        public $idade;


        public function __construct($nome, $idade) {
            $this -> nome = $nome;
            $this -> idade = $idade;
        }

        public function getNome() {
            return $this -> nome;
        }    

        public function getIdade() {
            return $this -> idade;
        }   

        public function emitirSom(){
            echo "<p>O Macaco faz: UH AH AH UH AH AH";
        }
    }