<?php
    class Comprador{
        private $nome;
        private $verba;


        public function __construct($nome, $verba){
            $this-> nome = $nome;
            $this-> verba = $verba;
        }

        public function comprar(){
            echo "<p>Compra realizada. Comprador: " . $this->nome;
        }

        public function __toString(){
            return "<p> Comprador: " . $this->nome;
        }
    }

