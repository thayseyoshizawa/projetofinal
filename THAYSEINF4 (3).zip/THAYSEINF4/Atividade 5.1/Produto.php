<?php
    class Produto{
        private $descricao;
        private $preco;


        public function __construct($descricao, $preco){
            $this-> descricao = $descricao;
            $this-> preco = $preco;
        }

        public function __toString(){
            return "<p>" . $this->descricao . ": " . $this->preco;
        }
    }

