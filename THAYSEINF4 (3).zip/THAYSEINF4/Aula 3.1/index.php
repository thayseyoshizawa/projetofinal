<?php
    require 'carro.php';

    // intanciano um objeto
    $meuCarro = new Carro("Toyota", "Corolla", 2025);

    // INVOCAR O MÉTODO
    $meuCarro->Imprimir();


